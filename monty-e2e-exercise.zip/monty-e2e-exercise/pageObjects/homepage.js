export const gotoPage = () => {
    browser.url('/')
}

export const hasLogo = () => {
    browser.isVisible(".BrandLogo-img")
}

export const showMeSummerSale = () => {
    browser.click("div.CmsComponent:nth-child(12) > div:nth-child(1) > a:nth-child(1) > img:nth-child(1)")
}