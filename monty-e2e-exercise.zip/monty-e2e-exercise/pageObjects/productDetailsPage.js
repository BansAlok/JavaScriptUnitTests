const expect = require('chai').expect;


export const selectFilter = () => {
    browser.click(".Button.Filters-refineButton")
 
}

export const filterBy = (filter) => {
    for (var i = 1; i <= 12; i++) {
        if (filter == browser.getText(".Refinements-content > div:nth-child(2) > article:nth-child(" + i + ")")) {
            browser.click(".Refinements-content > div:nth-child(2) > article:nth-child(" + i + ")")
            
            break;
        }
    }
}

export const ChooseColour = (colour) => {
    for (var i = 1; i < 17; i++) {
        
        var colourFromBrowser = browser.getText(".Refinements-content > div:nth-child(2) > article:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > button:nth-child("+i+")");
        var newColour = colourFromBrowser.split(' ')[0];
        if (colour==newColour) {
            browser.click(".Refinements-content > div:nth-child(2) > article:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > button:nth-child(" + i +")");
            break;
        }
    }

}

export const ApplyFilter = () => {
    browser.click(".Button.Refinements-applyButton");
}

export const VerifyNumberOfFilterSeleted = (filterCount) => {
    expect("("+filterCount+")").to.be.eql(browser.getText(".Filters-refineButton > span"));
}

export const VerifyThatTheProductListIsAppearing = () => {
    expect(browser.isVisible(".ProductList")).to.be.true;
}

export const RemoveAllFilter = () => {
    browser.click(".Refinements-clearButton");
}

export const VerifyNoFilter = () => {
    expect(browser.getText(".Filters-refineButton > span")).is.empty;
}
