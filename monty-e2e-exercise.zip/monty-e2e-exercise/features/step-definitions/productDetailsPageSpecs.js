import * as productDetailsPage from '../../pageObjects/productDetailsPage'


module.exports = function () {
    this.When(/^I filter the product list$/, productDetailsPage.selectFilter)

    this.When(/^I filter by option "([^"]*)"$/, (filter) => {
        productDetailsPage.filterBy(filter);
    });

    this.When(/^I select colour '([^']*)'$/, (choosenColour) => {
        productDetailsPage.ChooseColour(choosenColour); 
    });

    this.When(/^I apply these filters$/, productDetailsPage.ApplyFilter)

    this.Then(/^Filter button has '([^']*)' filter$/, (filterCount) => {
        productDetailsPage.VerifyNumberOfFilterSeleted(filterCount);
    });

    this.Then(/^Filter returns a product list$/, productDetailsPage.VerifyThatTheProductListIsAppearing)

    this.When(/^I clear all filters$/, productDetailsPage.RemoveAllFilter)

    this.Then(/^Filter button has no filters$/, productDetailsPage.VerifyNoFilter )
}